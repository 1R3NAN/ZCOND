<?php
if(isset($_POST['submit']))
{

    
    include_once('config.php');
    
    $nome_empresa = $_POST['nome-empresa'];
    $nome_fundador = $_POST['nome-fundador'];
    $cpf_fundador = $_POST['cpf'];
    $cnpj_empresa = $_POST['cnpj'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $endereco = $_POST['endereco'];

    /*$result = mysqli_query($conexao, "INSERT INTO usuario(nome_empresa, nome_fundador, cpf_fundador, cnpj_empresa, email_empresa, telefone, senha) 
    VALUES('$nome_empresa','$nome_fundador', '$cpf_fundador', '$cnpj_empresa', '$email_empresa', '$telefone', '$senha')");*/

    $sql_code = "INSERT INTO condominios(nome_empresa, nome_fundador, cpf_fundador, cnpj_empresa, email, telefone, endereco) 
    VALUES('$nome_empresa','$nome_fundador', '$cpf_fundador', '$cnpj_empresa', '$email', '$telefone', '$endereco')";
    $sql_query = $conexao->query($sql_code) or die("Falha na execução do código SQL: " . $conexao->error);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZCOND</title>
    <link rel="shortcut icon" href="./imagem/favicon.png">
    <link rel="stylesheet" href="header2.css">
    <link rel="stylesheet" href="painel.css">
    <link rel="stylesheet" href="cadas-cond.css">
</head>
<body>
    <iframe src="header2.html"></iframe>
    <main>  
        <div class="lasanha">
            <div class="painel">
                <div class="foto">
                    <label class="picture" for="picture__input" tabIndex="0">
                        <span class="picture__image"></span>
                    </label>
                    <input type="file" name="picture__input" id="picture__input">
    
                </div> 
                <div class="texto">
                    <ul>
                        <br>
                        <img class="icon" src="./PROJETO/imagem/house.png"><a class="inicio" href=""><li>Início</li></a>
                        <br>
                        <img class="icon" src="./PROJETO/imagem/relatorio.png"><a class="relatorio" href="relatorio.html"><li>Relatório</li></a>
                        <br>
                        <img class="icon" src="./PROJETO/imagem/notas.jpg"><a class="tarefas" href=""><li>Tarefas</li></a>
                        <br>
                        <img class="icon" src="./PROJETO/imagem/cadeado.png"><a class="reservas" href=""><li>Reservas</li></a>
                        <br>
                        <img class="icon" src="./PROJETO/imagem/notas.jpg"><a class="documentos" href=""><li>Documentos</li></a>
                        <br>
                        <img class="icon" src="./PROJETO/imagem/telefone.png"><a class="ocorrencias" href=""><li>Ocorrências</li></a>
                        <br>
                        <img class="icon" src="./PROJETO/imagem/usuario.png"><a class="registro" href=""><li>Registro</li></a>
                        <br>
                        <img class="icon" src="./PROJETO/imagem/notas.jpg"><a class="condominios" href="painel-central.php"><li>Condomínios</li></a>
                    </ul>
                </div>
            </div>
            <div class="hamburguer">
            <h1>registro condomínios</h1>
            <br>
            
            <form action="cadas-cond.php" method="POST" autocomplete="off">
                <input class="caixa" type="text" name="nome-empresa" placeholder="Nome da Empresa" autocomplete="off" required maxlength="30"/>
                <br>
                <input class="caixa" type="text" name="nome-fundador" placeholder="Nome do Fundador" autocomplete="off" required maxlength="30"/>
                <br>
                <input class="caixa" type="text" name="cpf" placeholder="CPF" autocomplete="off" required maxlength="11"/>
                <br>
                <input class="caixa" type="text" name="cnpj" placeholder="CNPJ" autocomplete="off" required maxlength="14"/>
                <br>
                <input class="caixa" type="text" name="email" placeholder="Digite seu e-mail..." autocomplete="off" required maxlength="64"/>
                <br>
                <input class="caixa" type="text" name="telefone" placeholder="Telefone..." autocomplete="off" required maxlength="21"/>
                <br>
                <input class="caixa" type="text" name="endereco" placeholder="Digite o seu endereço" autocomplete="off"/>
                <br>
            
                <input type="submit" name="submit" id="submit">
            </form>       
        </div>
    </main>
</body>
</html>