-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 13-Nov-2023 às 21:52
-- Versão do servidor: 5.6.10
-- versão do PHP: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `zcond`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `areas_comuns`
--

DROP TABLE IF EXISTS `areas_comuns`;
CREATE TABLE IF NOT EXISTS `areas_comuns` (
  `area_id` int(11) NOT NULL,
  `nome_do_condomino` varchar(100) DEFAULT NULL,
  `unidade_id` int(11) DEFAULT NULL,
  `condomino_id` int(11) DEFAULT NULL,
  `nome_condomino` varchar(100) DEFAULT NULL,
  `email_empresa` varchar(100) DEFAULT NULL,
  `dt_reserva` date DEFAULT NULL,
  PRIMARY KEY (`area_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `condominios`
--

DROP TABLE IF EXISTS `condominios`;
CREATE TABLE IF NOT EXISTS `condominios` (
  `condominio_id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_fundador` varchar(15) DEFAULT NULL,
  `nome_condominio` varchar(15) DEFAULT NULL,
  `cnpj` char(14) DEFAULT NULL,
  `cpf` char(11) DEFAULT NULL,
  `cep` varchar(8) DEFAULT NULL,
  `rg` varchar(10) DEFAULT NULL,
  `dt_nasc` varchar(10) DEFAULT NULL,
  `apartamentos` int(11) DEFAULT NULL,
  PRIMARY KEY (`condominio_id`),
  UNIQUE KEY `cpf` (`cpf`) USING BTREE,
  UNIQUE KEY `cnpj` (`cnpj`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `condominios`
--

INSERT INTO `condominios` (`condominio_id`, `nome_fundador`, `nome_condominio`, `cnpj`, `cpf`, `cep`, `rg`, `dt_nasc`, `apartamentos`) VALUES
(5, 'Luiz Tavares', 'ETEC', '21412412412412', '54912748912', '73158916', '215326246', '2023-12-07', 10);

-- --------------------------------------------------------

--
-- Estrutura da tabela `documentos`
--

DROP TABLE IF EXISTS `documentos`;
CREATE TABLE IF NOT EXISTS `documentos` (
  `documentos_id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) DEFAULT NULL,
  `descricao` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`documentos_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionarios`
--

DROP TABLE IF EXISTS `funcionarios`;
CREATE TABLE IF NOT EXISTS `funcionarios` (
  `funcionario_id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) DEFAULT NULL,
  `cpf` varchar(11) DEFAULT NULL,
  `telefone` int(10) DEFAULT NULL,
  `celular` int(8) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL,
  `cidade` varchar(30) DEFAULT NULL,
  `funcao` varchar(20) DEFAULT NULL,
  `admissao` date DEFAULT NULL,
  `demissao` date DEFAULT NULL,
  `dt_nasc` date DEFAULT NULL,
  PRIMARY KEY (`funcionario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `funcionarios`
--

INSERT INTO `funcionarios` (`funcionario_id`, `nome`, `cpf`, `telefone`, `celular`, `email`, `estado`, `cidade`, `funcao`, `admissao`, `demissao`, `dt_nasc`) VALUES
(1, 'Renan Torres Stabile', '5496306806', 32518693, 981444230, 'renan@gmail.com', 'SP', 'Santos', 'Dono', '2023-11-13', '2023-11-23', '2023-12-21');

-- --------------------------------------------------------

--
-- Estrutura da tabela `ocorrencias`
--

DROP TABLE IF EXISTS `ocorrencias`;
CREATE TABLE IF NOT EXISTS `ocorrencias` (
  `registro_id` int(11) NOT NULL AUTO_INCREMENT,
  `sujeito` varchar(30) NOT NULL,
  `funcao` varchar(30) NOT NULL,
  `solicitante` varchar(30) NOT NULL,
  `descricao` varchar(200) NOT NULL,
  PRIMARY KEY (`registro_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pessoas`
--

DROP TABLE IF EXISTS `pessoas`;
CREATE TABLE IF NOT EXISTS `pessoas` (
  `id_morador` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(30) DEFAULT NULL,
  `apartamento` int(4) DEFAULT NULL,
  `telefone` int(9) DEFAULT NULL,
  `celular` int(9) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `cpf` varchar(11) DEFAULT NULL,
  `rg` int(11) DEFAULT NULL,
  `data` date DEFAULT NULL,
  PRIMARY KEY (`id_morador`),
  UNIQUE KEY `email_condomino` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `relatorios`
--

DROP TABLE IF EXISTS `relatorios`;
CREATE TABLE IF NOT EXISTS `relatorios` (
  `relatorios_id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(200) DEFAULT NULL,
  `descricao` varchar(200) NOT NULL,
  `caminho_arquivo` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`relatorios_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `relatorios`
--

INSERT INTO `relatorios` (`relatorios_id`, `titulo`, `descricao`, `caminho_arquivo`) VALUES
(2, 'teste', 'teste', NULL),
(3, 'testeeeeeeeeeee', 'akle', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `reservas`
--

DROP TABLE IF EXISTS `reservas`;
CREATE TABLE IF NOT EXISTS `reservas` (
  `reservas_id` int(11) NOT NULL AUTO_INCREMENT,
  `area` varchar(15) DEFAULT NULL,
  `residencia` int(5) DEFAULT NULL,
  `solicitante` varchar(30) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `horario` time(4) DEFAULT NULL,
  `termino` time(4) DEFAULT NULL,
  `aluguel` int(10) DEFAULT NULL,
  `taxa` int(10) DEFAULT NULL,
  PRIMARY KEY (`reservas_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `reservas`
--

INSERT INTO `reservas` (`reservas_id`, `area`, `residencia`, `solicitante`, `data`, `horario`, `termino`, `aluguel`, `taxa`) VALUES
(7, 'Sala de Cinema', 8, 'renan', '2023-11-06', '14:13:00.0000', '18:11:00.0000', 1000, 1000),
(8, 'Salão de Festa', 4, 'lucas', '2023-11-23', '16:30:00.0000', '19:00:00.0000', 100, 50),
(9, 'Sala de Cinema', 0, 'teste', '2023-11-22', '19:54:00.0000', '20:54:00.0000', 1900, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `usuario_id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_empresa` varchar(100) DEFAULT NULL,
  `nome_fundador` varchar(100) DEFAULT NULL,
  `cpf_fundador` char(11) DEFAULT NULL,
  `cnpj_empresa` char(14) DEFAULT NULL,
  `email_empresa` varchar(100) DEFAULT NULL,
  `telefone` varchar(21) DEFAULT NULL,
  `senha` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`usuario_id`),
  UNIQUE KEY `cpf_fundador` (`cpf_fundador`),
  UNIQUE KEY `cnpj_empresa` (`cnpj_empresa`),
  UNIQUE KEY `email_empresa` (`email_empresa`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`usuario_id`, `nome_empresa`, `nome_fundador`, `cpf_fundador`, `cnpj_empresa`, `email_empresa`, `telefone`, `senha`) VALUES
(6, 'Samsung', 'Renan Stabile', '08980721378', '68676134781', 'renan@gmail.com', '32518693', 'renanlindomaravilhoso'),
(7, 'thanus', 'lucas', '63141341241', '646464252325', 'lucas@gmail.com', '213213', '123'),
(8, 'a', 'a', 'a', 'a', 'a', 'a', 'a');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
