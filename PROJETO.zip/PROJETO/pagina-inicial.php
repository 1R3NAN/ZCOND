<?php
    session_start();
    include_once('config.php');
    // print_r($_SESSION);

    if((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true) and (!isset($_SESSION['nome_fundador']) == true))
    {
        unset($_SESSION['email']);
        unset($_SESSION['senha']);
        unset($_SESSION['fundador']);
        
        header('Location: login.php');
    }
    $logado = $_SESSION['email'];
    
    if(!empty($_GET['search']))
    {
        $data = $_GET['search'];
        $sql = "SELECT * FROM usuario WHERE id LIKE '%$data%' or nome LIKE '%$data%' or email LIKE '%$data%' ORDER BY id DESC";
        $_session["nome_empresa"] = $nome_empresa;
        $_session["nome_fundador"] = $nome_fundador;
    }
    else
    {
        $sql = "SELECT * FROM usuario ORDER BY id DESC";
    }
    
    $sql2 = "SELECT * FROM usuario WHERE  email_empresa = \"$logado\"";
   
    $result2 = $conexao->query($sql2);

    $row = $result2->fetch_assoc();
    



    $sql3 = "SELECT nome_fundador, nome_condominio FROM condominios";
    $result3 = $conexao->query($sql3);
    $row3 = $result3->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZCOND</title>
    <link rel="stylesheet" href="pagina-inicial.css">
    <link rel="shortcut icon" href="./imagem/favicon.png">
</head>
<body>
    <main>
        <div class="menu">
            <img class= "logo" src="./imagem/logo.png" height="65px" width="170px">
            <style>.logo{margin: 10px;}</style>
            <div class="lista">
                    <ul>
                        <br>
                        <div class="inicio"><img class="icon" src="/PROJETO/imagem/house.png"><a class="inicio" href="pagina-inicial.php"><li>Início</li></a></div>
                        
                        <div class="relatorio"><img class="icon" src="/PROJETO/imagem/relatorio.png"><a class="relatorio" href="relatorio.php"><li>Relatório</li></a></div>

                        <div class="reservas"><img class="icon" src="/PROJETO/imagem/cadeado.png"><a class="reservas" href="reserva.php"><li>Reservas</li></a></div>
                    
                        <div class="documentos"><img class="icon" src="/PROJETO/imagem/notas.jpg"><a class="documentos" href="documento.php"><li>Documentos</li></a></div>
                    
                        <div class="ocorrencias"><img class="icon" src="/PROJETO/imagem/telefone.png"><a class="ocorrencias" href="ocorrencia.php"><li>Ocorrências</li></a></div>
                    
                        <div class="registro"><img class="icon" src="/PROJETO/imagem/usuario.png"><a class="registro" href=""><li>Registro</li></a></div>
                        
                        <div class="condominiu"><img class="icon" src="/PROJETO/imagem/notas.jpg"><a class="condominiu" href="painel-central.php"><li>Funcionário</li></a></div>
                    </ul>
            </div>
            </div>
        </div>
        <div class="conteudo-1">
            <div class="perfil">
                <div class="texto">
                    <h1>Olá</h1>
                    <h1><?php echo $row["nome_fundador"];?></h1>
                    <h2>Tenha um ótimo trabalho!</h2></div>

                <img src="./imagem/image 13.png"><style>img{display:flex ; margin-left: 15px;}</style>
            </div>
            <div class="conteudo-2">
                <p>Codomínios</p>
                <br>
                <div class="condominios">
                    <div class="predio">
                        <img src="./imagem/cinza.png">
                        <div class="texto2"><h4><?php echo $row3["nome_condominio"];?></h4><h4><?php echo $row3["nome_fundador"];?></h4></div>
                    </div>
                    <input class="botao"type="submit" name="submit" id="submit" value="criar">
                </div>
                <br>
                <div class="condominios2">
                    <div class="predio2">
                        <img class="isso"src="./imagem/cinza.png">
                        <div class="texto3"><h4>Adicionar nome</h4><h4>Adicionar nome</h4></div>
                    </div>
                    <input class="botao"type="submit" name="submit" id="submit" value="criar">
                </div>
                <br>
                <div class="condominios2">
                    <div class="predio2">
                        <img class="isso"src="./imagem/cinza.png">
                        <div class="texto3"><h4>Adicionar nome</h4><h4>Adicionar nome</h4></div>
                    </div>
                    <input class="botao"type="submit" name="submit" id="submit" value="criar">
                </div>
                <br>
                <div class="condominios2">
                    <div class="predio2">
                        <img class="isso"src="./imagem/cinza.png">
                        <div class="texto3"><h4>Adicionar nome</h4><h4>Adicionar nome</h4></div>
                    </div>
                    <input class="botao"type="submit" name="submit" id="submit" value="criar">
                </div>
            </div>
        </div>
        <div class="conteudo-3">
            <div class="zcond">
                <img class="logozcond"src="./imagem/zcond logo.png" width="300px"><style>.logozcond{margin: 0px;}</style>
            </div>
            <div class="divs">
                <div class="div-1">
                    <br>
                    <p>Nome</p>
                    <p><?php echo $row["nome_fundador"]; ?></p>
                    <br>
                    <p>CPF</p>
                    <p><?php echo $row["cpf_fundador"]; ?></p>
                    <br>
                    <p>E-mail</p>
                    <p><?php echo $row["email_empresa"]; ?></p>
                    <br>
                    <p>Telefone</p>
                    <p><?php echo $row["telefone"];?></p>

                </div>
                <div class="div-2">
                    <br>
                    <p>Empresa</p>
                    <p><?php echo $row["nome_empresa"]; ?></p>
                    <br>
                    <p>CNPJ</p>
                    <p><?php echo $row["cnpj_empresa"]; ?></p>
                    <br>

                </div>

            </div>
        </div>
    </main>
</body>
</html>