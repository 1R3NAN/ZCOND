<?php
    session_start();
    include_once('config.php');
    // print_r($_SESSION);
    if((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true))
    {
        unset($_SESSION['email']);
        unset($_SESSION['senha']);
        header('Location: login.php');
    }
    $logado = $_SESSION['email'];
    if(!empty($_GET['search']))
    {
        $data = $_GET['search'];
        $sql = "SELECT * FROM usuarios WHERE id LIKE '%$data%' or nome LIKE '%$data%' or email LIKE '%$data%' ORDER BY id DESC";
    }
    else
    {
        $sql = "SELECT * FROM usuarios ORDER BY id DESC";
    }
    $result = $conexao->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZCOND</title>
    <link rel="stylesheet" href="header2.css">
    <link rel="stylesheet" href="painel.css">
    <link rel="shortcut icon" href="./imagem/favicon.png">
</head>
<body>
    <iframe src="header2.html"></iframe>
<main>  
    <div class="lasanha">
        <div class="painel">
            <div class="foto">
                <label class="picture" for="picture__input" tabIndex="0">
                    <span class="picture__image"></span>
                </label>
                <input type="file" name="picture__input" id="picture__input">

            </div> 
            <div class="texto">
                <ul>
                    <br>
                    <img class="icon" src="/PROJETO/imagem/house.png"><a class="inicio" href=""><li>Início</li></a>
                    <br>
                    <img class="icon" src="/PROJETO/imagem/relatorio.png"><a class="relatorio" href="relatorio.html"><li>Relatório</li></a>
                    <br>
                    <img class="icon" src="/PROJETO/imagem/notas.jpg"><a class="tarefas" href=""><li>Tarefas</li></a>
                    <br>
                    <img class="icon" src="/PROJETO/imagem/cadeado.png"><a class="reservas" href=""><li>Reservas</li></a>
                    <br>
                    <img class="icon" src="/PROJETO/imagem/notas.jpg"><a class="documentos" href=""><li>Documentos</li></a>
                    <br>
                    <img class="icon" src="/PROJETO/imagem/telefone.png"><a class="ocorrencias" href=""><li>Ocorrências</li></a>
                    <br>
                    <img class="icon" src="/PROJETO/imagem/usuario.png"><a class="registro" href=""><li>Registro</li></a>
                    <br>
                    <img class="icon" src="/PROJETO/imagem/notas.jpg"><a class="condominios" href="painel-central.php"><li>Condomínios</li></a>
                </ul>
            </div>
        </div>
        <div class="hambur">
            <div class="palmito">
                <h3>condominios</h3>
            </div>
            <div class="pesquisa">
                <input class="caixa" type="text" name="e-mail" placeholder="Buscar Condomínios" />
                <button class="buscar" href="#">buscar</button>
                <button href="condominio.php" class="filtro" href="cadas-cond.php">criar</button>
            </div>
            <div class="tabelas">
                <?php
                    $sql = 'SELECT * FROM  condominios';



                ?>
                <div class="a1">
                    <h2>
                        ${condominios}
                    </h2>
                    <button>
                        entrar
                    </button>
                </div>
            </div>
        </div>
    </div>
</main>
</body>
<script src="upgrade.js"></script>
<script src="painel.js"></script>
</html>